/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto_biblioteca;


import DAO.AdminDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Usuario;
import model.Biblioteca;
/**
 *
 * @author Aline Rocha
 */
public class Projeto_Biblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Usuario usuario1 = new Usuario();
        Biblioteca biblioteca1 = new Biblioteca();
        
        
        usuario1.setNome("Nina");
        usuario1.setCpf("444.444.444-44");
        usuario1.setEmail("nina@gmail.com");
        usuario1.setSenha("ninazinha");
        
        salvarUsuario(usuario1);
        
        
        
        biblioteca1.setNome("Biblioteca Monteiro Lobato");
        biblioteca1.setEstado("Rio de Janeiro");
        biblioteca1.setCidade("Rio de Janeiro");
        biblioteca1.setBairro("Copacabana");
        biblioteca1.setRua("Carambola");
        biblioteca1.setNumero(28);
        
        salvarBiblioteca(biblioteca1);
        //CadastroUsuarioFrame cadUsuario = new CadastroUsuarioFrame(usuario1);
        //cadUsuario.setVisible(true);
    }

    
    public static void salvarUsuario(Usuario usuario){
        String nome = usuario.getNome();
        String cpf = usuario.getCpf();
        String email = usuario.getEmail();
        String senha = usuario.getSenha();

        Conexao conexao = new Conexao();

        try{
            Connection conn = conexao.getConnection();
            AdminDAO dao = new AdminDAO(conn);
            dao.inserirUsuario(nome, email, senha, cpf);
            JOptionPane.showMessageDialog(null, "Usuário Cadastrado",
                    "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Usuário Não Cadastrado",
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

    }
    
    
    public static void salvarBiblioteca(Biblioteca biblioteca){
        String nome = biblioteca.getNome();
        String estado = biblioteca.getEstado();
        String cidade = biblioteca.getCidade();
        String bairro = biblioteca.getBairro();
        String rua = biblioteca.getRua();
        int numero = biblioteca.getNumero();

        Conexao conexao = new Conexao();

        try{
            Connection conn = conexao.getConnection();
            AdminDAO dao = new AdminDAO(conn);
            dao.inserirBiblioteca(nome, estado, cidade, bairro, rua, numero);
            JOptionPane.showMessageDialog(null, "Biblioteca Cadastrada",
                    "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Biblioteca Não Cadastrada",
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }

    }
    
    
}
