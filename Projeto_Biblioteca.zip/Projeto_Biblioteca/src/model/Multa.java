/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author Aline Rocha
 */
public class Multa {
    private int idEmprestimo;
    private float valorTotal;
    private LocalDate dataMulta;
    private int diasAtraso;
    private boolean estaPago;
    private LocalDate dataPagamento;


    public Multa(int idEmprestimo, float valorTotal, int diasAtraso) {
        this.idEmprestimo = idEmprestimo;
        this.valorTotal = valorTotal;
        this.diasAtraso = diasAtraso;
        this.estaPago = false;
    }

    public Multa() {
    }
    
    public void calcularValor() {
        // O usuário precisa pagar 2 reais por cada dia de atraso na devolucao
        this.valorTotal = 2 * this.diasAtraso;
    }
    
    public void pagar() {
       this.estaPago = true;
       this.dataPagamento = LocalDate.now();
    }

    public int getIdEmprestimo() {
        return idEmprestimo;
    }

    public void setIdEmprestimo(int idEmprestimo) {
        this.idEmprestimo = idEmprestimo;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDate getDataMulta() {
        return dataMulta;
    }

    public void setDataMulta(LocalDate dataMulta) {
        this.dataMulta = dataMulta;
    }

    public int getDiasAtraso() {
        return diasAtraso;
    }

    public void setDiasAtraso(int diasAtraso) {
        this.diasAtraso = diasAtraso;
    }

    public boolean isEstaPago() {
        return estaPago;
    }

    public void setEstaPago(boolean estaPago) {
        this.estaPago = estaPago;
    }

    public LocalDate getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(LocalDate dataPagamento) {
        this.dataPagamento = dataPagamento;
    }
    
    
}
