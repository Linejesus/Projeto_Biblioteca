/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAO.AdminDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Usuario;
import view.CadastroUsuarioFrame;

/**
 *
 * @author Aline Rocha
 */
public class CadastroUsuarioController {
    private CadastroUsuarioFrame view;
    private Usuario usuario;

    public CadastroUsuarioController(CadastroUsuarioFrame view, Usuario usuario) {
        this.view = view;
        this.usuario = usuario;
    }

    public CadastroUsuarioController() {
    }
    
    public void salvarUsuario(){
        String nome = view.getTxtNome().getText();
        String cpf = view.getTxtCPF().getText();
        String email = view.getTxtEmail().getText();
        String senha = view.getTxtSenha().getText();

        Conexao conexao = new Conexao();
        
        try{
            Connection conn = conexao.getConnection();
            AdminDAO dao = new AdminDAO(conn);
            dao.inserirUsuario(nome, email, senha, cpf);
            JOptionPane.showMessageDialog(view, "Usuário Cadastrado",
                    "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e){
            JOptionPane.showMessageDialog(view, "Usuário Não Cadastrado",
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
        
    }
    
}
